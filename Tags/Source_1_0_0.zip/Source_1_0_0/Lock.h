#include <18F252.h> // C:\Program Files (x86)\PICC\Devices


/*-----------------------------------------------------------------------------
                                     CONFIGURACION
-----------------------------------------------------------------------------*/
#device ADC=16

#FUSES PROTECT // Protege la memoria de programa para no lecturas
#FUSES CPD     // Protege la memoria EEPROM
#FUSES NOCPD     //BORRA GAPB
#FUSES NOWDT // DESACTIVA EL PERRO GUARDIAN DEL FUSE---> NECESARIO PARA ACTIVAR/DESACTIVAR EL PERRO GUARDIAN EN LA RUTINA PRINCIPAL
#FUSES WDT64 // CONFIGURA PRE ESCALER EN 1,152 SEGUNDOS

#FUSES NOBROWNOUT               //No brownout reset
#FUSES NOLVP                    //No low voltage prgming, B3(PIC16) or B5(PIC18) used for I/O
#FUSES NOPUT   // No power up timer
#FUSES HS      // Oscilador 

#USE delay ( crystal=20000000 )  // Velocidad

// Configura usar el modulo USART por hardware
#USE rs232 ( UART1, BAUD=9600, PARITY=E, BITS = 8, STOP=1, TIMEOUT=20 )


/*-----------------------------------------------------------------------------
                                     DEFINICIONES
-----------------------------------------------------------------------------*/

// Tamanos buffers
#define	LENGTH_BUFFRX	40
#define	LENGTH_BUFFTX	20

// Encabezado trama
#define HEAD_BYTE	0x03


// Definicion de comandos---------------------------------------------------------------------------------------------------
#define COMMAND_OPEN          	0x10  // Comando desbloqueo cerradura
#define COMAND_LOCK					0x11  // Comando bloqueo cerradura
#define COMMAND_STATUS        	0x20  // Comando lectura sensores
#define COMAND_TIMEOUT        	0xF0  // COMANDO DE TIME OUT POR BYTE NO RECIBIDO EN LA TRAMA
#define COMMAND_EEPROM_WRITE  	0x40  // COMANDO ESCRITURA EEPROM
#define COMAND_EEPROM_READ    	0x41  // COMANDO LECTURA EEPROM
#define COMAND_EEPROM_FORMAT  	0x42  // COMANDO FORMATEAR BLOQUE EEPROM


// Defincion de respuestas
#define ANS_OK    				0xA0
#define ANS_ERROR_FORMAT   	0xE0	// Error formato comando
#define ANS_ERROR_CRC			0xE1	// Error CRC
#define ANS_ERROR_UNKNOWN		0xE2	// Error comando desconocido
#define ANS_ERROR_VALUE			0xE3	// Error uno de los valores fuera de rango
#define ANS_ERROR_LENGTH		0xE4	// Error longitud comando y datos
#define ANS_ERROR_INITIALIZE	0xF0	// Error bloque sin inicializar bloque
#define ANS_ERROR_CONDITION	0XF1	// Error condiciones de acceso
#define ANS_ERROR_KEY			0xF2	// Error la llave no es la correcta

// Formatos para campos de fecha y hora
#define FORMAT_24H	0
#define FORMAT_12H	1
#define TIME_AM		0
#define TIME_PM		1

// Constante para el desbordamiento del TMR0 cada 10ms OSC 20MHZ
#define TIMER_TMR0_10M		25535

// Tiempo maximo de espera de un byte luego de iniciar recepcion comando en 10ms*
#define TIMEOUT_RXCOMMAND 2

// Tiempo para mantener el pulso necesario actuador lineal 10ms*
#define TIMEOUT_PULSELOCK 200

// Tiempo para mantener el pulso que activa el solenoide en 10ms*
#define TIMEOUT_SOLENOIDE 300

// Estados logicos
#define STATUS_UNITIALIZE	0
#define STATUS_INITIALIZE	1
#define STATUS_ERROR			2
#define STATUS_FREE			4
#define STATUS_WAIT			5
#define STATUS_OPEN			6
#define STATUS_LOCK			7
#define STATUS_BLOCKFORMAT	8
#define STATUS_WRITEEEPROM	50

// Definicion subprocesos
#define STEP_START			0
#define STEP_AUTHENTICATE	1
#define STEP_UNLOCK_START	20
#define STEP_UNLOCK_PULSE	21
#define STEP_UNLOCK_WAIT	22
#define STEP_LOCK_START		30
#define STEP_LOCK_PULSE		31
#define STEP_LOCK_WAIT		32

// Definicion de pines especiales
#define PIN_LED				PIN_C5
#define PIN_BUZZER			PIN_B7

// Cerradura 1 tipo A
#define PIN_1_IA				PIN_C0
#define PIN_1_IB				PIN_C1
#define PIN_1_LI				PIN_B0
#define PIN_1_LO				PIN_B1
#define PIN_1_SL				PIN_A0
#define PIN_1_SD				PIN_A1

// Cerradura 2 tipo A
#define PIN_2_IA				PIN_C2
#define PIN_2_IB				PIN_C3
#define PIN_2_LI				PIN_B2
#define PIN_2_LO				PIN_B3
#define PIN_2_SL				PIN_A2
#define PIN_2_SD				PIN_A3

// Cerradura 3 tipo B
#define PIN_3_IA				PIN_C4
#define PIN_3_SL				PIN_A4
#define PIN_3_SD				PIN_A5

// MAscara de bits sensores
#define MASK_SD				0b00000001
#define MASK_SL				0b00000010
#define MASK_LO				0b00010000
#define MASK_LI				0b00100000



/*
#define PIN_LED				PIN_A1
#define PIN_BUZZER			PIN_C4
#define PIN_1_IA				PIN_C0
#define PIN_1_IB				PIN_C1
#define PIN_1_LI				PIN_C2
#define PIN_1_LO				PIN_C3
*/

// Numero de bytes por cada bloque
#define BLOCK_LENGTH			5

// Mascara de condicione de acceso
#define PERMISSION_FORMAT	0b10000000	// Permiso inicializar condiciones del bloque
#define PERMISSION_AUTH		0b00001000	// Permiso autenticar
#define PERMISSION_WRAUTH	0b00000100	// Permiso escritura con autenticacion
#define PERMISSION_WR		0b00000010	// Permiso escritura sin autenticacion
#define PERMISSION_R			0b00000001	// Permiso lectura sin autenticacion


/*-----------------------------------------------------------------------------
                                     FUNCIONES
-----------------------------------------------------------------------------*/
extern int8 CalcCRC ( unsigned char * data );   
extern void ClearBufferRx ( void ); 
extern void ClearBufferTx ( void );
extern int8 CompareBuffer ( int8 * tempData1, int8 * tempData2, int8 tempLenght );
extern int8 GetSensorStatus ( void );
extern void ReadEEprom ( int8 * tempPtr, int8 tempAddress, int8 tempSize );
extern void SendByte ( int8 tempData );
extern void SendAns ( int8 tempCommand, int8 tempAns );   
extern void SendAnsComplex ( int8 tempCommand, int8 tempAns, int8 *tempPointer, 
							int8 tempLength );
extern int8 ValidateCommand ( void );
extern void WriteEEprom ( int8 * tempPtr, int8 tempAddress, int8 tempSize );





